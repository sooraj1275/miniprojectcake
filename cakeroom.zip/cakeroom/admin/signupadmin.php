<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>
    <link rel="stylesheet" href="../css/style2.css"/>
</head>
<body>
<?php
    require('../confg/connection.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['admin_username'])) {
        // removes backslashes
        $admin_username = stripslashes($_REQUEST['admin_username']);
        //escapes special characters in a strings
        $admin_username = mysqli_real_escape_string($conn, $admin_username);
        $admin_email    = stripslashes($_REQUEST['admin_email']);
        $admin_email    = mysqli_real_escape_string($conn, $admin_email);
        $admin_password = stripslashes($_REQUEST['admin_password']);
        $admin_password = mysqli_real_escape_string($conn, $admin_password);
        $query    = "INSERT into `cake_shop_admin_registration` (admin_username, admin_password, admin_email)
                     VALUES ('$admin_username', '" . md5($admin_password) . "', '$admin_email')";
        $res   = mysqli_query($conn, $query);
        if ($res) {
            echo "<div class='form'>
                  <h3>You are registered successfully.</h3><br/>
                  <p class='link'>Click here to <a href='loginadmin.php'>Login</a></p>
                  </div>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='registration.php'>registration</a> again.</p>
                  </div>";
        }
    } else {
    
?>

    <form class="form" action="signupadmin.php" method="post">
        <h1 class="login-title">Registration</h1>
        <input type="text" class="login-input" name="admin_username" placeholder="Username" required s>
        <input type="text" class="login-input" name="admin_email" placeholder="Email Adress" required>
        <input type="password" class="login-input" name="admin_password" placeholder="Password" required>
        <input type="submit" name="submit" value="Register" class="login-button">
        <div class="text">
        <p class="link"><a href="loginadmin.php">Click to Login</a></p>
    </form>
<?php
    }
?>
</div>
</body>
</html>