<?php 
include('logincheck.php');
?>
<html>
    <head>
        <title>cake order website-homepage</title>
       <link rel="stylesheet" href="../css/admin.css">
        
</head>
<body>
    <!-- menu section starts -->
    <div class="menu text-center">
        <div class="wrapper">
        <ul>
            <li><a href="adminhm.php">Home</a></li>
            <li><a href="manageuser.php">user</a></li>
            <li><a href="managecakes.php">cakes</a></li>
            <li><a href="manage-order.php">order</a></li>
            <li><a href="managecategory.php">category</a></li>
            <li><a href="logout-admin.php">logout</a></li>
        </ul>
</div>
</div>
    <!-- menu section ends -->
    