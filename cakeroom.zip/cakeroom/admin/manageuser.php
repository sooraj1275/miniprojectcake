<?php include('partials/menu.php');
?>
<!--?php include('../confg/connection.php');?-->

    <!-- content section starts-->
    <div class="content">
    <div class="wrapper">
        <h1>Manage users</h1>
        <br>
        <?php
        
        if(isset($_SESSION['delete']))
        {
            echo $_SESSION['delete'];
            unset($_SESSION['delete']); 
        

        }
        if(isset($_SESSION['update']))
        {
            echo $_SESSION['update'];//displaying the updated message
            unset ($_SESSION['update']);//error message
        }
            
        ?>
        <br><br><br>
        <!-- button to add user -->
    <h2>view user details</h2>
        <table class="tbl-full">
            <tr>
                <th>id</th>
                <th>name</th>
                <th>email</th>
                <th>password</th>
                <th>phoneno</th>
                <th>address</th>
                <th>actions</th>
                
</tr>
   <?php
               //query to get all users
               $sql="SELECT * FROM `usertable`";

               //execute the query
           $res = mysqli_query($conn,$sql);

         // check whether the query executed or not
    if($res==TRUE)
  {
             //count rows to check whether we have the data in database

               $count = mysqli_num_rows($res);//function to get all rows in databse.
               $sn=1;//display id in order

              //check the number of rows 
     
              if($count>0)
    
              {
          
                //we have data in database
        
                while($rows=mysqli_fetch_assoc($res))
      
                {
           
                    //using while loop to get the all data from database;
            

            
                    //get individual data
            $id=$rows['id'];
            $name=$rows['name'];
            $email=$rows['email'];
            $password=$rows['password'];
            $phoneno=$rows['phoneno'];
            $address=$rows['address'];

            //display the values in our table
            ?>

<tr>
<td><?php echo $sn++; ?>.</td>
 <td><?php echo $name; ?></td>
 <td><?php echo $email; ?></td>
 <td><?php echo $password; ?></td>
<td><?php echo $phoneno;?></td>
 <td><?php echo $address;?></td>
 <td>
                 <a href="<?php echo SITEURL; ?>admin/update-user.php?id=<?php echo $id; ?>" class="btn-secondary">Update</a>
              <br>
                 <a href="<?php echo SITEURL; ?>admin/deleteuser.php?id=<?php echo $id; ?>" class="btn-danger">Delete</a>
    
 </td>
</tr>
<?php
        } 
    
     }
     else{
         //no data in database
     }

 }

?>
</table>

</div>
</div>
    <!-- content section ends -->

  <?php include('partials/footer.php');?>
