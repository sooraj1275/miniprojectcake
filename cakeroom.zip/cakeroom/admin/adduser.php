<?php
 include('partials/menu.php');
 ?>
 <?php include('../confg/connection.php');?>
 

<div class="content">
    <div class="wrapper">
        <h1>Add user</h1>
        <br><br>

         <?php
          if(isset($_SESSION['add']))/// checking whether the session set or not
          {
              echo $_SESSION['add'];//  dispay the the message if set
              unset($_SESSION['add']);// remove the message
          }
         ?>
        <form action="" method="POST">
            <table class="tbl30">
                <tr>
                    <td>username</td>
                    <td><input type="text" name="username" placeholder="username"></td>
                  </tr>
                 <tr>
                    <td>emailid</td>
                    <td><input type="text" name="emailid" placeholder="emailid"></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="adduser" class=btn-secondary>
                    </td>
                </tr>
            </table>
        </div>
</div>
<?php include('partials/footer.php');?>
<?php
// process the value form and save it  in database,cakeroom
//check whether the submit button is clicked or not
if (isset($_POST['submit']))
{
    // button clicked
   // echo "button clicked";

   // get the data from our form
    $username = $_POST['username'];
    $emailid =$_POST['email'];
    
    //sql query to insert data into data base
    $sql = "INSERT INTO usertable SET 
            username = '$username',
            emailid ='$emailid'
    ";
    // executing query and saving data into database
    $res = mysqli_query($conn, $sql) or die(mysqli_error());
    
    // check whether  the query is  executed or not 
    if($res==true)
    {
        //data inserted
       // echo "data inserted";
       //create a session variable to display message
      $_SESSION['add'] = "user added successfully";
       //redirect page
       header("location:".SITEURL.'admin/manageuser.php');

    }
    else{
        // echo "failed to insert";
        $_SESSION['add'] = "failed";
        //redirect page
        header("location:".SITEURL.'admin/adduser.php');
    }
}


?>
        