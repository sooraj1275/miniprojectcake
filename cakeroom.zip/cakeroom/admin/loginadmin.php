<?php include('../confg/connection.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login to cakeroom</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style2.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <!-- login form starts here -->
                <form action="" method="POST" autocomplete="">
                    <h2 class="text-center">Login Form</h2>
                    <p class="text-center">Login to access admin panel.</p><br>
                    <?php
                     if(isset($_SESSION['login']))
                     {
                         echo $_SESSION['login'];
                         unset($_SESSION['login']);
                     }
                     ?>
                     <br>
                    <div class="form-group">
                        <input class="form-control" type="name" name="admin_username" placeholder="username" required >
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="admin_password" placeholder="Password" required>
                    </div>
                    <!--<div class="link forget-pass text-left"><a href="forgot-password.php">Forgot password?</a></div>-->
                    <div class="form-group">
                        <input class="btn-primary" type="submit" name="submit" value="Login">
                    </div>
                    <div class=" text-center">Not yet a member? <a href="signupadmin.php">Signup now</a></div>
                </form>
                <!-- login form ends here -->
            </div>
        </div>
    </div>
    
</body>
</html>
<?php 
// check whether the button is clicked or not
if(isset($_POST['submit'])){
    
    //process for login
    //get the data from login form
   $admin_username =$_POST['admin_username'];
    $admin_password = md5($_POST['admin_password']);

    //sql to check whether the user name and password exists
    $sql = "SELECT * FROM cake_shop_admin_registration WHERE  admin_username ='$admin_username' AND admin_password = '$admin_password'";

    //to execute the query
    $res = mysqli_query($conn,$sql);

    //count rows to check whether the user exists or not
    $count = mysqli_num_rows($res);

    if($count==1)
    {
        //user available and login successful 
        $_SESSION['login'] = "<div class='success'>login successful.</div>";

        //check whether the admin logged in or not
        $_SESSION['admin'] = $admin_username;

        
        //redirect to home page /dashboard
        header('location:'.SITEURL.'admin/adminhm.php');

    }
    else{
         //user is not available and login failed
         $_SESSION['login'] = "<div class = 'error text_center'>user name or password didnt match.</div>";
         //redirec to home page/ login page
         header('location:'.SITEURL.'admin/loginadmin.php');
    }
}
?>

