<?php
// include connection
include('../confg/connection.php');

// get the id of the  user to be deleted
 $id = $_GET['id'];


//create sql query to delete user
$sql = "DELETE FROM usertable WHERE id = $id";

//execute the query
$res = mysqli_query($conn, $sql);

//check whethe the query executed or not
if($res==true)
{
    //query executed successfully
    //"user deleted successfully";
    //create session vaariable to display message
    $_SESSION['delete'] ="<div class='success'>user deleted successfully.</div>";
    // redirect to manage user.php
    header('location:'.SITEURL.'admin/manageuser.php');
}
else
{
    //failed to delet
  // echo "failed to delete";
  $_SESSION['delete'] ="<div class='error'>failed to delete, try again later.</div>";
  header('location:'.SITEURL.'admin/manageuser.php');
}


//redirect to managge user

?>