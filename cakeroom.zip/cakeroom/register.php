<html>
    <head>
        <title>registration -cakeroom</title>
        <link rel ="stylesheet" href ="css/user.css">
        <link rel ="stylesheet" href="css/style2.css">
</head>
<body>
<?php
    require('confg\connection.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['name'])) {
        // removes backslashes
        $name = stripslashes($_REQUEST['name']);
        //escapes special characters in a strings
        $name = mysqli_real_escape_string($conn, $name);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($conn, $email);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($conn, $password);
        $phoneno = stripslashes($_REQUEST['phoneno']);
        $phoneno    = mysqli_real_escape_string($conn, $phoneno);
        $address = stripslashes($_REQUEST['address']);
        $address   = mysqli_real_escape_string($conn, $address);
        $query    = "INSERT into `usertable` (name, email, password, phoneno,address)
                     VALUES ('$name', '$email','" . md5($password) . "', '$phoneno','$address')";
        $res   = mysqli_query($conn, $query);
        if ($res) {
            echo "<div class='container'>
                  <h3>You are registered successfully.</h3><br/>
                  <p class='link'>Click here to <a href='loginuser.php'>Login</a></p>
                  </div>";
        } else {
            echo "<div class='container'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='register.php'>registration</a> again.</p>
                  </div>";
        }
    } else {
?>
    <div class= "container">
        <span class="circle1"></span>
        <span class="circle2"></span>
                <!-- registration  form starts he-->
        
         <form class="form" action="" method="POST" autocomplete="">
             <br><br>
                 <h2 class="text-center" align="center">register Form</h2>
                    <p class="text-center" align="center">register for yourcakeroom.</p><br>
         <div class="inputs">
             <br><br>
            <input type="text" name="name" placeholder=" username" class="input-field">
            <br>
            <input type="email" name="email" placeholder=" email" class="input-field">
            <br>
            <input type="password" name="password" placeholder=" password" class="input-field">
            <br>
            <input type="password" name="confirmpassword" placeholder="retype password" class="input-field">
            <br>
            <input type="number" name="phoneno" placeholder="phone no" class="input-field">
            <br>
            <input type="text" name="address" placeholder="Address" class="input-field">
            <br><br>
            <div class ="btn">
                <button type="submit">Register</button>
             </div>
             <br><br>
             <div class="text">
                 <p class="link">already a member ?<a href ="loginuser.php">Login here</a></p>

             </div>

                

    </div>
    </form>
    <?php
    }
    ?>
</body>
</html>