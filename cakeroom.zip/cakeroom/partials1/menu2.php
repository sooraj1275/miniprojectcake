<?php include('usercheck.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--title><;?php echo $fetch_info['name'] ?> | Home</title-->
    <link rel="stylesheet" href="css/style.css">
    
</head>
<body>
    <h1>Welcome <!--?php echo $fetch_info['name'] ?--></h1>
    <!-- Navbar Section Starts Here -->
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="images/logo.jpg" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="<?php echo SITEURL;?>home.php">Home</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL; ?>categories.php">categories</a>
                    </li>
                    <li>
                        <a href= "<?php echo SITEURL; ?>cakes.php">cakes</a>
                    </li>
                    <li>
                        <a href="#contact">contact us</a>
                    </li>
                    <li>
                    <!-- a href="addtocart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span>cart</a-->
    
                    </li>
                    <li>
                        <a href='logoutuser.php'>Logout</a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Navbar Section Ends Here -->
   