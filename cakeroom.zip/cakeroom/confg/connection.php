<?php
// start session
session_start();


//create constants
define('SITEURL','http://localhost/cakeroom/');
define('LOCALHOST','localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'cakeroom');

$conn = mysqli_connect('LOCALHOST','root', '')
or //database coonection
die(mysqli_error());
$db_select = mysqli_select_db($conn, 'cakeroom') //database selection
or
die(mysqli_error());

?>