<?php include('C:\xampp\htdocs\cakeroom\partials1\menu1.php');?>


    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="cakesearch.php" method="POST">
                <input type="search" name="search" placeholder="Search for cakes.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore cakes</h2>

            <a href="category-cakes.php">
            <div class="box-3 float-container">
                <img src="images/menu2.jpg" alt="cake" class="img-responsive img-curve">

                <h3 class="float-text text-white"></h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/menu3.jpg" alt="cupcake" class="img-responsive img-curve">

                <h3 class="float-text text-white"></h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/menu8.jpg" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white"></h3>
            </div>
            </a>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
<section class="food-menu">
    <div class="container">
        <h2 class="text-center">cake Menu</h2>

        <?php 
        
        //Getting Foods from Database that are active and featured
        //SQL Query
        $sql2 = "SELECT * FROM cake WHERE active='Yes' AND featured='Yes' LIMIT 2";

        //Execute the Query
        $res2 = mysqli_query($conn, $sql2);

        //Count Rows
        $count2 = mysqli_num_rows($res2);

        //CHeck whether cake available or not
        if($count2>0)
        {
            //Food Available
            while($row=mysqli_fetch_assoc($res2))
            {
                //Get all the values
                $id = $row['id'];
                $title = $row['title'];
                $price = $row['price'];
                $description = $row['description'];
                $image_name = $row['imagename'];
                ?>

                <div class="food-menu-box">
                    <div class="food-menu-img">
                        <?php 
                            //Check whether image available or not
                            if($image_name=="")
                            {
                                //Image not Available
                                echo "<div class='error'>Image not available.</div>";
                            }
                            else
                            {
                                //Image Available
                                ?>
                                <img src="<?php echo SITEURL; ?>images/cakes/<?php echo $image_name; ?>" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                                <?php
                            }
                        ?>
                        
                    </div>

                    <div class="food-menu-desc">
                        <h4><?php echo $title; ?></h4>
                        <p class="food-price"><?php echo $price; ?></p>
                        <p class="food-detail">
                            <?php echo $description; ?>
                        </p>
                        <br>

                        <a href="<?php echo SITEURL; ?>order.php?food_id=<?php echo $id; ?>" class="btn btn-primary">Order Now</a>
                        <!--button class="btn btn-info btn-block addItemBtn">&nbsp;&nbsp;Add to
                  cart</button-->
                    </div>
                </div>

                <?php
            }
        }
        else
        {
            //Food Not Available 
            echo "<div class='error'>Food not available.</div>";
        }
        
        ?>

        <div class="clearfix"></div>
</div>

    <p class="text-center">
        <a href="cakes.php" class="btn btn-primary" >TRy OuR varieties!</a>
    </p>
</section>
<!-- fOOD Menu Section Ends Here -->

<?php include('C:\xampp\htdocs\cakeroom\partials1\footer1.php');

?>