-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 25, 2021 at 02:22 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cakeroom`
--
CREATE DATABASE IF NOT EXISTS `cakeroom` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cakeroom`;

-- --------------------------------------------------------

--
-- Table structure for table `cake`
--

CREATE TABLE `cake` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `imagename` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake`
--

INSERT INTO `cake` (`id`, `title`, `description`, `price`, `imagename`, `category_id`, `featured`, `active`) VALUES
(8, 'Black forest', 'its yummy and delicious', '340', 'instagram-3.jpg', 19, 'No', 'No'),
(10, 'whiteforest', 'its very tasty', '500', 'dish2.jpg', 22, 'Yes', 'Yes'),
(11, 'choco triffle cake', 'its very tasty', '170', 'dish7.jpg', 19, 'Yes', 'Yes'),
(12, 'icecream cake', 'its very tasty', '400', 'dish8.jpg', 22, 'Yes', 'Yes'),
(13, 'biscof ', 'it very tasty', '230', 'dish6.jpg', 21, 'Yes', 'Yes'),
(14, 'cupcake', 'itz yummy', '230', 'b3.jpg', 20, 'Yes', 'Yes'),
(15, 'unicorn', 'its very tasty', '300', 'instagram-2.jpg', 22, 'Yes', 'Yes'),
(16, 'Red velvet', '', '600', 'rr.jpg', 22, 'Yes', 'Yes'),
(17, 'Pinapple cake', '', '550', 'jk.jpg', 22, 'Yes', 'Yes'),
(18, 'Crunchy butterscotch cake', '', '700', 'll.jpg', 22, 'Yes', 'Yes'),
(19, 'Plum cake', '', '300', 'oo.jpg', 22, 'Yes', 'Yes'),
(20, 'Kit kat cake', '', '1000', 'yy.jpg', 22, 'Yes', 'Yes'),
(21, 'Donuts', '', '100', 'dd.jpg', 19, 'Yes', 'Yes'),
(22, 'Brownie', '', '150', 'bbb.jpg', 21, 'Yes', 'Yes'),
(23, 'Milk cake', '', '600', 'mm.jpg', 22, 'Yes', 'Yes'),
(24, 'Rainbow cake', '', '1000', 'tt.jpg', 22, 'Yes', 'Yes'),
(25, 'Chocolate cake', '', '800', 'qq.jpg', 22, 'Yes', 'Yes'),
(26, 'Christmas cake', '', '900', 'uu.jpg', 22, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_admin_registration`
--

CREATE TABLE `cake_shop_admin_registration` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(100) NOT NULL,
  `admin_email` varchar(150) NOT NULL,
  `admin_password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_admin_registration`
--

INSERT INTO `cake_shop_admin_registration` (`admin_id`, `admin_username`, `admin_email`, `admin_password`) VALUES
(7, 'admin', 'cakeroom18@gmail.com', '4432aae46b3e5d83b621f7f7fdbfafec');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` varchar(255) NOT NULL,
  `imagename` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `totalprice` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `image_name` varchar(10) NOT NULL,
  `featured` text NOT NULL,
  `active` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(19, 'donuts', 'cake_Categ', 'Yes', 'Yes'),
(20, 'cupcakes', 'cake_Categ', 'Yes', 'Yes'),
(21, 'pasteries', 'cake_Categ', 'Yes', 'Yes'),
(22, 'cakes', 'cake_Categ', 'Yes', 'Yes'),
(23, 'the threst', 'cake_Categ', 'Yes', 'Yes'),
(24, 'newon', 'cake_Categ', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(1, 'white', '342.00', 1, '342.00', '2021-12-20 12:06:17', 'Ordered', 'shibla', '9061031233', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(2, 'whiteforest', '500.00', 2, '1000.00', '2021-12-20 12:12:40', 'Ordered', 'shibla', '9061031233', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(3, 'whiteforest', '500.00', 1, '500.00', '2021-12-20 12:30:22', 'Ordered', 'tester', '76543213354', 'shahushibu05@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(4, 'whiteforest', '500.00', 1, '500.00', '2021-12-20 12:33:08', 'On Delivery', 'asdfghj', '76543213354', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(5, 'whiteforest', '500.00', 1, '500.00', '2021-12-20 12:34:56', 'Delivered', 'shibla', '9061031233', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(6, 'icecream cake', '400.00', 1, '400.00', '2021-12-21 06:42:32', 'Delivered', 'angana raj m', '9645659995', 'aishu1234@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(7, 'Brownie', '150.00', 1, '150.00', '2021-12-22 07:15:44', 'Ordered', 'shibla', '9061031233', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(8, 'Brownie', '150.00', 1, '150.00', '2021-12-22 07:17:17', 'Ordered', 'shibla', '76543213354', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(9, 'Brownie', '150.00', 1, '150.00', '2021-12-22 07:47:04', 'Ordered', 'shibla', '76543213354', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(10, 'whiteforest', '500.00', 1, '500.00', '2021-12-22 08:49:33', 'Ordered', 'cvghjk', '741085296', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(11, 'cupcake', '230.00', 1, '230.00', '2021-12-23 05:18:13', 'Ordered', 'drishya', '9645659995', 'angana@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST'),
(12, 'Black forest', '342.00', 3, '1026.00', '2021-12-23 08:26:08', 'Ordered', 'aiswarya', '76543213354', 'aiswaryaharidas5428@gmail.com', 'machingal house'),
(13, 'icecream cake', '400.00', 2, '800.00', '2021-12-23 11:04:52', 'Ordered', 'we', '9061031233', 'anganarajm@gmail.com', 'MANGATTIL HOUSE\r\nMADIRASSERY\r\nTHRIKKANAPURAM POST');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneno` int(11) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `phoneno`, `address`) VALUES
(20, 'shibla', 'shahushibu05@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 345678915, 'MANGATTIL HOUSE'),
(21, 'shibla', 'anganarajm@gmail.com', '7d77a7ac7f8cf5eb29af05ec996f5b52', 12345677, 'MANGATTIL HOUSE'),
(22, 'nameera', 'nameera@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 2147483647, 'MANGATTIL HOUSE'),
(23, 'shahul hameed', 'shahulhmiid@gmail.com', 'c7e3dc71ae705aba90ced0971d511353', 2147483647, 'ponnani'),
(24, 'aiswarya haridas', 'aiswaryaharidas5428@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 2147483647, 'machingal house1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cake`
--
ALTER TABLE `cake`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cake_shop_admin_registration`
--
ALTER TABLE `cake_shop_admin_registration`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cake`
--
ALTER TABLE `cake`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `cake_shop_admin_registration`
--
ALTER TABLE `cake_shop_admin_registration`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
